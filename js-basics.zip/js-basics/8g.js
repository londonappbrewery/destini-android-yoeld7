const message = "Hey";
const result = message.repeat(2);