const stg1 = 'HeLLO';
stg2 = stg1.toLowerCase();
