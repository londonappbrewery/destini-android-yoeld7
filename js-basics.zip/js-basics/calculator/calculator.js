let calculation= JSON.parse(localStorage.getItem('sav'));
      if (!calculation){calculation='';}
      updateTextOfCalculation(calculation);

      function updateCalculation(value){
        if(value === '='){
          calculation = eval(calculation);
          updateTextOfCalculation(calculation);
        }
        else if (value === 'clear'){
          calculation='';
          console.log('Cleared.');
          localStorage.removeItem('sav');
          updateTextOfCalculation();
        }
        else{
          calculation+=value;
          updateTextOfCalculation(calculation);
        }
        localStorage.setItem('sav', JSON.stringify(calculation));
      }

      function updateTextOfCalculation(calculation=''){
        document.querySelector('.calculation-result-viewer').innerHTML=calculation
      }