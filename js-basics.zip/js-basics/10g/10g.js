function buttonClicking(parameter){
  removeOtherToggles();
  const buttonElement = document.querySelector(`.js-${parameter}-button`);
  if(buttonElement.classList.contains('is-toggled')){
   buttonElement.classList.remove('is-toggled');
  }
  else{
   buttonElement.classList.add('is-toggled');
  }
 }

 function removeOtherToggles(){
  const button = document.querySelector('.is-toggled');
  if(button){
    button.classList.remove('is-toggled');
  }
 }