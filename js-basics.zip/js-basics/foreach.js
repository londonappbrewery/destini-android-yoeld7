//we can itrate in array with forEach loop
// for each strings forEach will save it into value inside the function
//this is the prefered way to loop through array
[
  'make dinner',
  'wash dishes',
  'watch youtube'
].forEach(function(value){
  console.log(value)
});

//we can also access the index using second parameter

[
  'make dinner',
  'wash dishes',
  'watch youtube'
].forEach(function(value, index){
  console.log(index);
  console.log(value);
});

// we can skip iteration using return statement, do the same thing
// as continue

[
  'make dinner',
  'wash dishes',
  'watch youtube'
].forEach(function(value, index){
  if (value==='wash dishes') return;
  console.log(index);
  console.log(value);
});

// if need to break, or exit the loop earlier its better to use
// regular for loop

