function buttonClicking(parameter){
  const buttonElement = document.querySelector(`.js-${parameter}-button`);
  if(buttonElement.classList.contains('is-toggled')){
   buttonElement.classList.remove('is-toggled');
  }
  else{
   buttonElement.classList.add('is-toggled');
  }
 }