const regularFunction = function (param, param2){
  console.log('hello');
  return 5;
};

const arrowFunction = (param, param2) => {
  console.log('hello');
};

const arrowFunctionNoParam = () => {
  console.log('hello');
};

//call the arrowFunction with no parameters
arrowFunctionNoParam();

//arrow function shorcuts
//when arrow function have only one parameter
//the round brackets is not needed
const oneParam = param => {
  console.log(param+1);
};

//if arrow function have only one line we can
//put it in the same line as the arrow
// the curly brackets and the return are not needed

const oneLine = () => 2+3;

//calling oneLine
console.log(oneLine());

//when passing a function into another function its recommended
//to use arrow function, for example in forEach loop

[
  'make dinner',
  'wash dishes',
  'watch youtube'
].forEach((value, index) =>{
  console.log(index);
  console.log(value);
});


//arrow function can be use in object as well

const object2 = {
  method: () => {

  },
  //shorthand method below:
  //recommened to use than arrow function
  method (){

  }
};



